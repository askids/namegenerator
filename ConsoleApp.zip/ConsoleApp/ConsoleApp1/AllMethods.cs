﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public enum Gender
    {
        Male = 0,
        Female = 1
    }

    public static class AllMethods
    {
        public static void UpdateCount(List<LastNameObj> values, long TotalCount)
        {
            foreach (LastNameObj lnObj in values)
            {
                lnObj.count = Convert.ToInt64((TotalCount * lnObj.percentage) / 100);
            }
        }

        public static void ShowAll(List<LastNameObj> values)
        {
            foreach (LastNameObj lnObj in values)
            {
                Console.WriteLine(string.Format("Name:{0}, Count: {1}", lnObj.LastName, lnObj.count));
            }
        }

        public static DateTime GenererateRandomDate(int inpYear)
        {
            var rnd = new Random();
            int year = rnd.Next(inpYear, inpYear+1);
            int month = rnd.Next(1, 12);
            int day = DateTime.DaysInMonth(year, month);

            int Day = rnd.Next(1, day);

            DateTime dt = new DateTime(year, month, Day);
            return dt;
        }
    }

}
