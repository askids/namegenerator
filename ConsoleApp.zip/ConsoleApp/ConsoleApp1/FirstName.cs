﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class FirstNameObj
    {
        public string FirstName;
        public Gender NameGender;
        public long Count;
        public long Assigned = 0;

        public long Remaining
        {
            get
            {
                return Count - Assigned;
            }
        }

        public static FirstNameObj FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            FirstNameObj objValues = new FirstNameObj();
            objValues.FirstName = values[0];
            objValues.NameGender = (values[1] == "M" ? Gender.Male : Gender.Female);
            objValues.Count = Convert.ToInt64(values[2]);
            return objValues;
        }

    }
}
