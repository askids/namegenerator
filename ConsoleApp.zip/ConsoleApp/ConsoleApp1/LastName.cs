﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class LastNameObj
    {
        public string LastName;
        public decimal percentage;
        public long count;
        public long Assigned;

        public long Remaining
        {
            get
            {
                return count > 0 ? count - Assigned : 0;
            }
        }

        public static LastNameObj FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            LastNameObj objValues = new LastNameObj();
            objValues.LastName = values[0];
            objValues.percentage = Convert.ToDecimal(values[1]);
            return objValues;
        }
    }

}
