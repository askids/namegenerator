﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Person
    {
        [JsonIgnore]
        public string SSN;
        public string ssn
        {
            get
            {
                return string.IsNullOrEmpty(SSN) ? "" : ssn;
            }
        }
        public string firstname;
        public string lastname;
        [JsonIgnore]
        public Gender PersonGender;
        public string gender
        {
            get
            {
                return PersonGender.ToString();
            }
        }

        [JsonIgnore]
        public DateTime DateOfBirth;
        public string dateofbirth
        {
            get
            {
                return DateOfBirth.ToString("yyyy-MM-dd");
            }
        }

        public string displayname
        {
            get
            {
                return string.Format("{0} {1}", firstname, lastname);
            }
        }
        public Person()
        {

        }

        public Person(int Year, string inpFirstName, string inpLastName, Gender inpGender)
        {
            firstname = inpFirstName;
            lastname = inpLastName;
            PersonGender = inpGender;
            SetDOB(Year);
        }

        public void SetDOB(int Year)
        {
            DateOfBirth = AllMethods.GenererateRandomDate(Year);
        }
    }
}
