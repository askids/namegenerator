﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class ThreadFileInfo
    {
        public int ThreadId;
        public string fileno;
    }

    class Program
    {
        static int i = 0;
        static void Main(string[] args)
        {
            List<ThreadFileInfo> ThreadList = new List<ThreadFileInfo>();
            List<long> PersonCount = new List<long>();
            List<LastNameObj> Lnvalues = File.ReadAllLines("D:\\Data\\namesbystate\\LastNamePct.csv")
                                           .Select(v => LastNameObj.FromCsv(v))
                                           .ToList();
            Console.WriteLine(Lnvalues.Count.ToString());

            AllMethods.UpdateCount(Lnvalues, 300000000);

            for (i = 0; i <= 200; i++)
            {
                ThreadList.Add(new ThreadFileInfo { ThreadId = i });
            }

            for (i = 2016; i >= 1940; i--)
            {
                Console.WriteLine("Processing Year:" + i.ToString());
                FirstNameByYear fny = new FirstNameByYear(i);
                
                Parallel.ForEach(fny.fnList,
                    new ParallelOptions { MaxDegreeOfParallelism = 8 },
                    (fnObj) =>
                    //foreach(FirstNameObj fnObj in fny.fnList)
                       {
                           int FileLineCount = 0;
                           int LocalCount = 0;
                           string fileno = ThreadList[Thread.CurrentThread.ManagedThreadId].fileno;
                           List<Person> personList = new List<Person>();
                           bool LimitReached = false;
                           foreach (LastNameObj lnObj in Lnvalues.FindAll(x => x.Remaining > 0))
                           {
                               if (!LimitReached)
                               {
                                   personList.Add(new Person(i, fnObj.FirstName, lnObj.LastName, fnObj.NameGender));
                                   lock (Lnvalues)
                                   {
                                       lnObj.Assigned++;
                                   }

                                   lock (fny)
                                   {
                                       fnObj.Assigned++;
                                       if (fnObj.Remaining <= 0)
                                       {
                                           LimitReached = true;
                                       }
                                   }

                                   FileLineCount++;

                                   if (FileLineCount >= 50000)
                                   {
                                       lock (PersonCount)
                                       {
                                           PersonCount.Add(personList.Count);
                                           LocalCount += personList.Count;
                                       }
                                       Console.WriteLine(string.Format("Write to File for year {0}, current count: {1}", i, PersonCount.Sum()));
                                       fileno = WriteToFile(i, personList, Thread.CurrentThread.ManagedThreadId, fileno);
                                       ThreadList[Thread.CurrentThread.ManagedThreadId].fileno = fileno;
                                       FileLineCount = 0;
                                       personList = new List<Person>();
                                   }
                               }
                               else
                               {
                                   break;
                               }
                           }

                           if (personList.Count > 0)
                           {
                               lock (PersonCount)
                               {
                                   PersonCount.Add(personList.Count);
                                   LocalCount += personList.Count;
                               }
                               //Console.WriteLine(string.Format("Write to File for year {0}, current count: {1}", i, personList.Count));
                               fileno = WriteToFile(i, personList, Thread.CurrentThread.ManagedThreadId, fileno);
                               ThreadList[Thread.CurrentThread.ManagedThreadId].fileno = fileno;
                               FileLineCount = 0;
                               personList = new List<Person>();
                           }

                           //Console.WriteLine(string.Format("Person Count for {0}: {1}",fnObj.FirstName, fnObj.Assigned));

                       }
                    );

            }

            Console.WriteLine(string.Format("Person Count: {0}", PersonCount.Sum()));
        }

        public static string WriteToFile(int Year, List<Person> personList, int ThreadId = 0, string inpfileno = "")
        {
            string fileno = string.IsNullOrEmpty(inpfileno) ? ThreadId.ToString().PadLeft(2, '0') + DateTime.Now.ToString("hhmmss") : inpfileno;
            string path = "D:\\Data\\PersonByYear" + Year.ToString() + "_" + fileno + ".txt";
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))
                {
                    StringBuilder sb = new StringBuilder();
                    foreach (Person p in personList)
                    {
                        //sb.AppendLine(p.FirstName + "," + p.LastName + "," + p.PersonGender.ToString() + "," + p.DateOfBirth.ToString());
                        sb.AppendLine("{ \"index\": { \"pipeline\": \"eslastupdatedts\"}}");
                        var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(p);
                        sb.AppendLine(jsonString);
                    }
                    sw.Write(sb.ToString());
                }
            }
            else
            {
                Int64 fileSizeInBytes = new FileInfo(path).Length;

                if ((Convert.ToDecimal(fileSizeInBytes)/(1024*1024)) >= 20)
                {
                    fileno = WriteToFile(Year, personList, ThreadId);
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(path))
                    {
                        StringBuilder sb = new StringBuilder();
                        foreach (Person p in personList)
                        {
                            //sb.AppendLine(p.FirstName + "," + p.LastName + "," + p.PersonGender.ToString() + "," + p.DateOfBirth.ToString());
                            sb.AppendLine("{ \"index\": { \"pipeline\": \"eslastupdatedts\"}}");
                            var jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(p);
                            sb.AppendLine(jsonString);
                        }
                        sw.Write(sb.ToString());
                    }
                }
            }

            return fileno;
        }
    }

    public class FirstNameByYear
    {
        public int Year;
        public List<FirstNameObj> fnList;

        public FirstNameByYear()
        {
            fnList = new List<FirstNameObj>();
        }

        public FirstNameByYear(int inpYear)
        {
            Year = inpYear;
            fnList = new List<FirstNameObj>();
            fnList = File.ReadAllLines("D:\\Data\\namebyyear\\yob" + inpYear.ToString() + ".txt")
                                           .Select(v => FirstNameObj.FromCsv(v))
                                           .ToList();
        }
    }
}